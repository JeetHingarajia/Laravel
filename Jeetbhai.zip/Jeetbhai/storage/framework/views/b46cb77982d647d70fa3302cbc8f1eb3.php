

<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('demo.store')); ?>" method="post">
  <?php echo csrf_field(); ?>
  <div class="mb-3">
    <label class="form-label">Name</label>
    <input type="text" name="name" class="form-control">
  </div>
  <div class="mb-3">
    <label class="form-label">City</label>
    <input type="text" name="city" class="form-control">
  </div>
  
  
    
  </div>
  
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Atmiya\Laravel\Jeetbhai\resources\views/user/create.blade.php ENDPATH**/ ?>