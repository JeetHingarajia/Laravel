

<?php $__env->startSection('content'); ?>

<form method="post">
  <?php echo csrf_field(); ?>
  
  <div class="mb-3">
    <label class="form-label">Name</label>
    <input type="text" name="name" value="<?php echo e($jeet->name); ?>" class="form-control" disable>
  </div>
  <div class="mb-3">
    <label class="form-label">City</label>
    <input type="text" name="city" value="<?php echo e($jeet->city); ?>"  class="form-control" disable>
  </div>
  
  
    
  </div>
  
  
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Atmiya\Laravel\Jeetbhai\resources\views/user/view.blade.php ENDPATH**/ ?>