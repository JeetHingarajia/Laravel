

<?php $__env->startSection('content'); ?>
<h1>
    Home Page
</h1>

<h1>Data</h1>
<table class="table table-border=4px">
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>City</th>
        <th>show</th>
        <th>Change</th>
        <th>Remove</th>
    </tr>
    <?php $__currentLoopData = $j; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($data->id); ?></td>
            <td><?php echo e($data->name); ?></td>
            <td><?php echo e($data->city); ?></td>
            <td>
                <form action="<?php echo e(route('demo.destroy',$data->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>   
                    <input type="submit" value="delete" class="btn btn-danger"></input>
                </form>
            </td>
            <td>
                <a href="<?php echo e(route('demo.edit',$data->id)); ?>" method="post" class="btn btn-info">
                    Edit
                </a>
            </td>
            <td>
            <a href="<?php echo e(route('demo.show',$data->id)); ?>" method="post" class="btn btn-warning">Show</a>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Atmiya\Laravel\Jeetbhai\resources\views/user/index.blade.php ENDPATH**/ ?>