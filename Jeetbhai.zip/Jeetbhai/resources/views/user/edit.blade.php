@extends('template.layout')

@section('content')

<form action="{{route('demo.update',$jeet->id)}}" method="post">
  @csrf
  @method('put')
  <div class="mb-3">
    <label class="form-label">Name</label>
    <input type="text" name="name" value="{{$jeet->name}}" class="form-control">
  </div>
  <div class="mb-3">
    <label class="form-label">City</label>
    <input type="text" name="city" value="{{$jeet->city}}"  class="form-control">
  </div>
  
  
    
  </div>
  
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>

@endsection