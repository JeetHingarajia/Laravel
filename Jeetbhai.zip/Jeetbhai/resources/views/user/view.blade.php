@extends('template.layout')

@section('content')

<form method="post">
  @csrf
  
  <div class="mb-3">
    <label class="form-label">Name</label>
    <input type="text" name="name" value="{{$jeet->name}}" class="form-control" disable>
  </div>
  <div class="mb-3">
    <label class="form-label">City</label>
    <input type="text" name="city" value="{{$jeet->city}}"  class="form-control" disable>
  </div>
  
  
    
  </div>
  
  
</form>

@endsection