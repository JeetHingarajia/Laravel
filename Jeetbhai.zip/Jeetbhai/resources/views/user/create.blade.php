@extends('template.layout')

@section('content')

<form action="{{route('demo.store')}}" method="post">
  @csrf
  <div class="mb-3">
    <label class="form-label">Name</label>
    <input type="text" name="name" class="form-control">
  </div>
  <div class="mb-3">
    <label class="form-label">City</label>
    <input type="text" name="city" class="form-control">
  </div>
  
  
    
  </div>
  
  
  <button type="submit" class="btn btn-primary">Submit</button>
</form>

@endsection