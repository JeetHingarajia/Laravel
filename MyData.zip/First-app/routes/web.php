<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Mycontroller as MyController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/',function(){
    return view('welcome');
});
Route::prefix('/blog')->group(function(){
    Route::get('/mypost/{id?}',[MyController::class, 'Home'])->name('Home');
    Route::get('/Aboutus',[MyController::class, 'Aboutus'])->name('Others.Aboutus');
    Route::get('/Contact',[MyController::class, 'Contact'])->name('Others.Contact');
});

