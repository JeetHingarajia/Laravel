@extends('templet.Layout')

@section('content')
<h1>Hello I'M Jeet Patel</h1>
<table class="table table-striped table-warning">
    @foreach($data as $datum)
    <tr>
        <td>{{$datum -> ID}}</td>
        <td>{{$datum ->first_name}}</td>
        <td>{{$datum ->last_name}}</td>
        <td>{{$datum ->email}}</td>
        <td>{{$datum ->gender}}</td>
        <td>{{$datum ->ip_address}}</td>
    </tr>
    @endforeach

</table>

<div class="container">
  
    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Molestiae itaque dolore voluptate dolores hic dolorum, earum distinctio quos nihil autem impedit suscipit voluptatibus dolorem repellendus quis, rerum laudantium maxime harum.</p>
</div>
@endsection
