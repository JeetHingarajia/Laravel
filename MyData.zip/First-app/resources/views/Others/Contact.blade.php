@extends('templet.Layout')

@section('content')
<p>9313840343</p>
@endsection
