@extends('templet.Layout')

@section('content')
<h1>About us</h1>
<p>hello Im Jeet Patel</p>
@endsection
