<?php $__env->startSection('content'); ?>
<p>9313840343</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templet.Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeetn\Downloads\First-app\First-app\resources\views/Others/Contact.blade.php ENDPATH**/ ?>