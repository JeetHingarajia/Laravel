<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <!-- header -->
        <h1>Jeet</h1>
        <!-- header end -->
        <!-- navbar -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">Navbar</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Link</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                Dropdown
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="#">Action</a></li>
                                <li><a class="dropdown-item" href="#">Another action</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item" href="#">Something else here</a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
                        </li>
                    </ul>
                    <form class="d-flex">
                        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                        <button class="btn btn-outline-success" type="submit">Search</button>
                    </form>
                </div>
            </div>
        </nav>

        <!--navbar end-->
        <div class="container">
            <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAMAAzAMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAAAQIDBQcGBAj/xABAEAABAwIFAQUFBQUGBwAAAAABAAIDBBEFBhIhMUETIlFhcQcUMoGRFSNCUqEzYpKy8HSCsdHS4RYXJDU2Q1T/xAAZAQEAAwEBAAAAAAAAAAAAAAAAAQIDBAX/xAAjEQEAAgIBBAIDAQAAAAAAAAAAAQIDERIEEyExQWEUIjJR/9oADAMBAAIRAxEAPwDiaIiqsIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIglCLK7W6e8dvJSHNeNLhv0KDEis5pHTZVQEUix2UkW46IKopKhAREQEREBERAREQEREBERAREQEREBERBYknlQiILNkI6fJTdh5BB8QsaIMoLejvqFN29T+ixKLoMhEfU8BHtA4URi7wCpkvc+tkGNERAREQEREBERAREQEREBERAREQEREGVoY42sVYxtWNmzgVnQY+zahjaBdXUP8AhKDES3oCqndQpQZIhsSptdvHVR/6T6oy5tY8IKOFifVQrkdwi9zdbDB8DqcWinlgmpoo4HMa508um7nXsB/CUS1ljdB035Xv6bJlJFRyGWVlTVGJwZ96NGo8G1xwPE89DwtJHlCaMj7RxXDaJn70+t3ya3lRFon0TDQU9NPUuc2ngllc1upwjYXEN6k26LER5r2Dsdp8tU/YZUdMJdbXVGITts+axuGNZ+Fl+b7lYql2W8yPNSJhgOIyG8sJYXUr3dXNI3ZfwOwU+R5QC4J8OUXt8BydTy+8israGpiey0MlPUjuu8dyLdOh68JP7PJpq6OHD8ToPvjaOOWoBfqtxtz1Vedd6TxnW3h0V5YzFK+N1tTHFpsbi42VFZUREQEREBERAREQXbyFnWBvIWdBCrJ8BV1ST4CgwqFKhBlbvER4FQzcG3ISI76ehSMaXOHBCC4aXubYEkjgBdFy3ljsMKLJ3uZU18ZjkubsaXFphd4Xa8A+J7wXm8h0clVmGCdkHaspQ6dzL/GGgmw8zY7eXRetx90n25gFJSxStZLXsDHyu3dpcNmtvs0Enc8keSxvaecVheseNy8k+zmBxj07X0kC4K+WQhuwsBf6LYYq5nv9ZoPcFTLp9NZt+i1kxXSylvMLyTU5hhmGF4ph0zogHSM1ODmg9bFqys9k2Ov2FVRbfvn/ACW29i5vmHEB0dSC/wDEusNbomPgV5vU9Tkx31V048VbRuX5vx/LbcDfLBU4rRSVUWzoIi4uB8OLL0XsswsSRYxirtTJIoPdKZ7RcsklB1OaPENB/iXmM5uLs1YqT/8AQ5egwKd1P7OjPGGuMOPxPe13BHZWF/LkLstynH78sfHJpM1YMcHxSWNgcKZxLoS7ezbkAH0stN6rqmbqF1bgNUI6aXtWNbM90ztRZoIaGh34r6gR4gLlW3Q3VcN+dNrXjUiIi1UEREBERAREQXbyFnWBnLfVZ0BUk+AqyrJ8BQYVClQgszZ4KudyXhYxysreD5oPfeyaOE1la+QGN/3YgqLd2OW7rNJ6a262262tyt/jMTqfFn5gkLC/D6GUQPuC01TnhjAB106yfVq0vsieTNiVPHpdK6NhET292cC506ujwW6m+PfW+zbCH4VVRNa5jKaXusItqe4GQn6H9CuO9uOdtWu6Odv7rdI4AXxynlbGjpKjEa+noqNuueofoYDx43PkACT6L3dR7KYmwBpxSXty2+rsxov6c2+a6r5qY9bllXHa3prPYubZirv7KP5l1+cWIcuTeyuimwvOGL0dSAJYIA11twd7gj1BC6qZNbRuvK63U5Nw7MMaq/M+cf8AyjE/7Q5bXIksdTT47glU5ograB8sWo2tPENcZ+e4872WozW9smZcSex2oGofv8192Q6L37GhCXaWvAZrHLSXDj5Ar1JnWLf044jd3VDEz7KbBU3k0MMUdIBrfJNosI7ckNd3vQX6LhgFtl3pr9UFTVuYYW9lJ207W6n3+AiNvVztJA9Vwd7tb3P0tbqJOlnA8gsOk/mWmb+oVREXWyERFAIiICIiC7f2nzWbqsIN5NvFZuqAqyHuqxIHKwvdfbogoOEREFm8rKfw+qpGLlWBNr9UHoMkTwQ5ihbVUkdSyUFjWE6Xh3LSx9xpdcc3XV3sFRUx0cplkDdQnbUx2kLXMc1rj0NidJI8lwgtsL8npboui5VzY2qp2QYji8lPUQAFhnhEkYYORrPfsRsbu9PLl6rHNq7hthvEeJfLgshyvnGlmrwW07HvjMh6NcC0O+tr/NdvdPB7n7y+RghDNXa6u7pte9/Bc2xKkwjGsLfBBUtqCx2qOSI63RBxvv1LQTz4Fc+kxHHcuTT4cyuqaZrdjCH6o3DxDTcWKw4fk63OphebduXQ8i1jcZznj2KUjS6kbCyFkhHxWP8AR9LK+eM80uC0s1FhszKjEHgjum7YQeSfPyXKKnMWMS0xp3YlUNgcd4oyI2u9Q211p9zfxXR+JE3i1vhn3piNQs8ue+7iXOcbk8kldNyDg76PC6ivdpZOXxtjMg2Y0Oa97j5BrT/RXmsmYD75Ux1dY14pmnuW/Fblx8GjxPWy95LiuEUkL3NxiGMN+8khYztSGiwa1oP4Rsb9SB0Vepyco4VTirr9pfBnWqgZgc9TJSSzds3TTPqRaOEHbusNiX2udRGy5Y7YkLa5hxqbGK9075ppWN2jMwAdp8w3ug+llqvRb4qcKaUvblO0IiLRQREQEREBERBkib3r9Fkc4DqsBJPUp6oLOddUREBWAuoAusg2G3KCWjbblLeHHmljbu/NQ64HPyQVeAeb3WSkqZqKqjqaZ5ZLG7U11hsfRYSbog6NgftAlqCyLF66no2sG8zaHW9x8tJs31IK9BieE0WcaBsEMtVNUwM+7xKaFsQ3AIaeNQII4C4yvTZWpTNBU4hiVTUMwagbeWNkpHbPPwxgcb9fJc98MRPKviWsZJmNT6aXGsLrMIqzTV8RY/o4btePEHqFusqZOqsWIqJ4ZPdgNQjbYPmHlfgef0WOfN9fUzSvqqejnYX64YpIgW09hYBngAFsMIrKjNNNJhz6l0OMQh0tFUMJZ2o5dC63Tq3w3Wtpvx/z7UiI29TV43hmB0uikxZ0Mun7ukrcOLmN03FgGgEbjkk8LwmZM2Yjj47GocyOlBBbEyMNsbdTyVpKh0xld7w5xlDiH6yS6/mSsXh4qMeGtfKbXmfAd1ClFoohERAREQEREBERAREQFIBPAQBZGj6oAaVPeHATS4cFVLnDlBJc/m2yxkkm6kuJ6qqAvTZWyTiOaKeWbDKqiHYuDZGTPe1zSePwkfQrQ0NFU4hUspqKB888nwxsFyf68V2H2N0FVhRxqjxKnfT1DZIiY5LX4NljnydukzHteldy5pRZVqa7MLsCp66hNcHuZYmQNLmglwB0eRW1xzBcTwWnpMuYpimGU8UkhqGd6TSSdu84M/xX15TI/wCcRJcLe+1e/wDckXpPaVFhk2YZHVkh7duFvNOwAaXOv1PjZVtlnuRWfmNp4/rMuf4zk+vwXE6PD66rou1q2gwvje9zCCbDcN8VscUybjGTXUmKVdfh8JEwEL2Pkf3rE8BnFgVrIqrEKn/hx9YCYIZuxpnk7lrZGkj0BNh/sur+0z3KpgwOLEXPjpjiLNRa0G/ddYeiZMtq3rWfkrXcTLnuI5LxfEqijxL3zCphjFV2cUkErtGstLt+5sO6fNY6H2c4tX19bRUtdhkktEWtntK+zSb2F9G/C+eixnEMKdVvomMfRUGJduwOOzJHCRjbeo/lXsfYhUvJxp8ji9z3Ruc48knUSUy3vjpNo+CteU6eLfknEG4filaysoJG4W5zaqNsj9bSDbYFouvNL0uOYvUUGZMyRRbx1r5YJWk8guuD6i36rzK2pMzG5VmBERWVEREBERAREQXcza4OyhrSdxwgJB2RziUF9mkKDp6XRtnjSVQixtZBJcehKhQiCUUIg2uWsany9i8WI07GSOYHAscbBwIsR62Xqqv2mVOqulw+mbFPVNawSSWPYtaLbDqdzufJeGpKqWjlMsAiLiLfewskH0cCF9n23W9I6Dx/7bT/AOhZ2xVtO5ja0WmH35PrpMPxn7WFDV18tKHvcIgSBqaQS4jjkn5LZZoxpuYqykxGqwjEIoXNEMWi+mXfhrrbnyC1GHZnrsPknkiipCZw0P8A+nbHp06gLBgAB7x352CtHmisigwqOOmpw/Dv2Umk3cN9nb/vHhRNN35a8kWnWm1xrFftGrw6ODAaylgwVu9OxpLmi7XDVttxyfFfbm3NL8z4dRQz4JWwRdvrhkYCRKbEWabb9ePBedoszVNDLUvpqena2ZwcA4yO7MhukEEuudidnXClmaa6OmoacQ02mie1zDpILy3XbUQd/wBofRV7Ubidek8p0+7EcQa/Lbsv0GA1dO+GYVU73tLn7AgueLXHPoFbJmcIMrQ1DW0T6mWpLS86wALeH1K+A5srDU1Uz6WkeKiBsDontc5jWtvbYk6iL8uutdFi1VDEyJjKItYLDXQQOPzJYSfUq3bi1ZrMG5j0Y7XQYlilRWwRvi94kMjmOINiSvhOy+6XF6uWJ8bmUQa8WOiggabeRDAR8l8C1jxGldiIiIEREBERAREQSoUkJpd+VBHVZHd5oKppd+WysA63VBRFYg9b/NRpPQXQQinS78qaXflQETS78qhAU3UIglFCIClQiJSoREQIiICIiAiIgIiIMkm5bZIeqoSrxclBaT4SsY23Cyv+ErHt2e3igs92qI+Kku0sB8li6WQnYBBki/Epl+A+qiLhySfAfVAjdfbwWM8lAbcIghERAREQEREBERAREQEREBERAREQf//Z"
                class="rounded float-start" alt="image1">
            <!--img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRVMBh_69F4bAxz3Fivgvg8KYsB3o1fw7rprA&usqp=CAU"
                class="rounded float-end" alt="image2"-->

        </div>
        <!--footer-->
        <div class="p-3 mb-2 bg-danger text-warning">
            <footer>Jeet Hingarajia @
        </div>
        </footer>
        <!--footer end-->
    </div>
</body>

</html>
<?php /**PATH E:\Jeet\First-app\resources\views/templet/index.blade.php ENDPATH**/ ?>