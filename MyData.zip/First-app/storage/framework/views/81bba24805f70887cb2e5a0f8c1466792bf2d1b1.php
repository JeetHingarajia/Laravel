<!--footer-->
<div class="p-3 mb-2 bg-danger text-warning">
    <footer>Jeet Hingarajia @
</div>
</footer>
<!--footer end-->
<?php /**PATH C:\Users\jeetn\Downloads\First-app\First-app\resources\views/templet/footer.blade.php ENDPATH**/ ?>