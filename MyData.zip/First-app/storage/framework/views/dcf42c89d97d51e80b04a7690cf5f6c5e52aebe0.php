<?php $__env->startSection('content'); ?>
<h1>Hello I'M Jeet Patel</h1>
<table class="table table-striped table-warning">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($datum -> ID); ?></td>
        <td><?php echo e($datum ->first_name); ?></td>
        <td><?php echo e($datum ->last_name); ?></td>
        <td><?php echo e($datum ->email); ?></td>
        <td><?php echo e($datum ->gender); ?></td>
        <td><?php echo e($datum ->ip_address); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<div class="container">
  
    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Molestiae itaque dolore voluptate dolores hic dolorum, earum distinctio quos nihil autem impedit suscipit voluptatibus dolorem repellendus quis, rerum laudantium maxime harum.</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templet.Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jeetn\Downloads\First-app\First-app\resources\views/Others/Home.blade.php ENDPATH**/ ?>