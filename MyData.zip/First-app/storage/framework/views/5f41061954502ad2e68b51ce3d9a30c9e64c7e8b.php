<?php $__env->startSection('content'); ?>
<h1>About us</h1>
<p>hello Im Jeet Patel</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templet.Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Jeet\First-app\resources\views/Others/Aboutus.blade.php ENDPATH**/ ?>