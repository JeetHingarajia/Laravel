<?php $__env->startSection('content'); ?>
<div class="container">
    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Molestiae itaque dolore voluptate dolores hic dolorum, earum distinctio quos nihil autem impedit suscipit voluptatibus dolorem repellendus quis, rerum laudantium maxime harum.</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templet.Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Jeet\First-app\resources\views/Others/Home.blade.php ENDPATH**/ ?>