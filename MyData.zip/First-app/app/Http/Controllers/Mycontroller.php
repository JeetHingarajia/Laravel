<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\models\Employee;

class Mycontroller extends Controller
{
    public function Home($id=null)
    {
        $data=Employee::get();
        return view('Others.Home',compact('data'));
        //return $data;
    }
    public function Aboutus($id=null)
    {
        return view('Others.Aboutus');
    }
    public function Contact($id=null)
    {
        return view('Others.Contact');
    }
}
