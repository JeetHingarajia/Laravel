@extends('template.layout')

@section('content')

<h1>Create a blog ....</h1>

<form action="{{route('mypost.store')}}" method="post">
    @csrf

    <input type="hidden" name="user_id" value="{{auth()->user()->id}}"/>
  <div class="form-group">
    <label>Title</label>
    <input type="text" name="title"class="form-control" placeholder="Enter Title">
   <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
  </div>
  <div class="form-group">
  <label>subtitle</label>
  <input type="text" name="subtitle"class="form-control" placeholder="Enter subTitle">
 <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>-->
</div>
<div class="form-group">
  <label>Body Content</label>
  <textarea class="form-control" name="body_content" placeholder="Enter BodyContent"></textarea>
 <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>-->
</div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>

@endsection