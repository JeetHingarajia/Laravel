 @extends('template.layout')

 @section('content')
<h1>My all Detail...</h1>
@php
    $i=1;
@endphp
@auth
 <p>Welcome,{{$user->name}} to my blog</p>
@endauth

@guest
 <p>Welcome Guest!! please login for more info <a href="">Login link</a></p>
@endguest


    <table class="table table-striped table-bordered table-hover">
        <thead>
            <tr>
                <td>S#</td>
                <td>Title</td>
                <td>UserName</td>
                <td>User Email</td>
                @auth
                <td>Edit</td>
                <td>Delete</td>
                @endauth
            </tr>
        </thead>
        <tbody>
            @forelse($posts as $post)
            <tr>
                <td>{{$post->id}}</td>
                <td>{{$post->title}}</td>
                <td>{{$post->getUser->name}}</td>
                <td>{{$post->getUser->email}}</td>
                @auth
                <td><input type="button" class="btn btn-primary"value="Edit"></td>
                <td><input type="button" class="btn btn-danger"value="Delete"></td>
                @endauth
            </tr>
            @empty
            <tr>
                <td colspan=6>No data found</td>
            </tr>
            @endforelse
        </tbody>
</table>
{{$posts->links()}}
 
@endsection