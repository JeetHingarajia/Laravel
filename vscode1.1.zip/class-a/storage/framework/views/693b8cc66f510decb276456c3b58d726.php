

<?php $__env->startSection('content'); ?>

<h1>Create a blog ....</h1>

<form action="<?php echo e(route('mypost.store')); ?>" method="post">
    <?php echo csrf_field(); ?>

    <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>"/>
  <div class="form-group">
    <label>Title</label>
    <input type="text" name="title"class="form-control" placeholder="Enter Title">
   <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
  </div>
  <div class="form-group">
  <label>subtitle</label>
  <input type="text" name="subtitle"class="form-control" placeholder="Enter subTitle">
 <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>-->
</div>
<div class="form-group">
  <label>Body Content</label>
  <textarea class="form-control" name="body_content" placeholder="Enter BodyContent"></textarea>
 <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>-->
</div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Atmiya\Laravel\class-a\resources\views/user/crate.blade.php ENDPATH**/ ?>