 

 <?php $__env->startSection('content'); ?>
<h1>My all Detail...</h1>
<?php
    $i=1;
?>
<?php if(auth()->guard()->check()): ?>
 <p>Welcome,<?php echo e($user->name); ?> to my blog</p>
<?php endif; ?>

<?php if(auth()->guard()->guest()): ?>
 <p>Welcome Guest!! please login for more info <a href="">Login link</a></p>
<?php endif; ?>


    <table class="table table-striped table-bordered table-hover">
        <thead>
            <tr>
                <td>S#</td>
                <td>Title</td>
                <td>UserName</td>
                <td>User Email</td>
                <?php if(auth()->guard()->check()): ?>
                <td>Edit</td>
                <td>Delete</td>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($post->id); ?></td>
                <td><?php echo e($post->title); ?></td>
                <td><?php echo e($post->getUser->name); ?></td>
                <td><?php echo e($post->getUser->email); ?></td>
                <?php if(auth()->guard()->check()): ?>
                <td><input type="button" class="btn btn-primary"value="Edit"></td>
                <td><input type="button" class="btn btn-danger"value="Delete"></td>
                <?php endif; ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan=6>No data found</td>
            </tr>
            <?php endif; ?>
        </tbody>
</table>
<?php echo e($posts->links()); ?>

 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Atmiya\Laravel\class-a\resources\views/user/index.blade.php ENDPATH**/ ?>